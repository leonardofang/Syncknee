import json
import os
import statistics
import joblib


for x in os.walk('Raw-data-1-30-2024/'):
    json_dir = [x[0]+target for target in x[2] if 'json' in target]
    print(json_dir)
print(len(json_dir))


all_data_ml = []
label = 0
for json_file in json_dir:
    print(json_file)
    data_sum = []
    f = open(json_file)
    data = json.load(f)
    len_data = len(data)
    print(len_data)
    # print(data[1])
    for string in data:
        numbers_as_strings = string['data'].split(',')
        numbers_as_integers = [int(number) for number in numbers_as_strings]
        # print(len(numbers_as_integers))
        if len(numbers_as_integers) == 4:
            data_sum.append(numbers_as_integers)
            data_point = numbers_as_integers[1:] + [label]
            # print(data_point)
            all_data_ml.append(data_point)
    # print(data_sum)
    transposed_data = zip(*data_sum)
    sums = [sum(column)/len_data for column in transposed_data]
    vars_sum = [statistics.stdev(column) for column in transposed_data]
    print(sums)
    label = (label + 1) % 5
    print(vars_sum)

# Separate data into labels and features
features = [item[:3] for item in all_data_ml]
labels = [item[3] for item in all_data_ml]

print(labels)
# Save features and labels
joblib.dump((features, labels), 'data_file.joblib')
