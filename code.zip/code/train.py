import scipy.io
import os
import numpy as np

# Load .mat file
for x in os.walk('data.xlsx/'):
    print(x)
    mat_dir = [x[0]+target for target in x[2] if 'mat' in target]
    print(mat_dir)
print(len(mat_dir))

x_list = []
y_list = []
z_list = []
label = []
for mat_file in mat_dir:
    mat_data = scipy.io.loadmat(mat_file)
    x_list.append(mat_data['Data'][0])
    y_list.append(mat_data['Data'][1])
    z_list.append(mat_data['Data'][2])
    if 'highKnee' in mat_file:
        label.append(0)
    elif 'lunge' in mat_file:
        label.append(1)
    elif 'sit' in mat_file:
        label.append(2)
    elif 'squat' in mat_file:
        label.append(3)
    else:
        label.append(4)
print(# x_list, '\n', y_list, '\n', z_list, '\n',
      'label list: ', label)

# Calculate lengths of each list
length_x = [len(lst) for lst in x_list]
length_y = [len(lst) for lst in y_list]
length_z = [len(lst) for lst in x_list]

# Find minimum and maximum lengths
min_length = min(min(length_x), min(length_y), min(length_z))
max_length = max(max(length_x), max(length_y), max(length_z))
print(min_length, max_length) # range 105 - 1275


# Interpolation Padding - mean values between neighboring pairs
def interpolate_list(lst, max_length):
    if len(lst) >= max_length:
        return lst
    interpolated = lst.copy()  # 创建副本以避免修改原始列表
    index = 0
    while len(interpolated) < max_length:
        interpolated = np.insert(interpolated, index+1, (interpolated[index] + interpolated[index + 1]) / 2)
        index += 2  # 每次插入后跳过插值的位置
        if index >= len(interpolated) - 1:
            index = 0  # 重新开始插值过程
    return interpolated


revised_x = []
for each in x_list:
    interpolated = []
    interpolated = interpolate_list(each, max_length)
    # print("Interpolated List:", interpolated_list)
    revised_x.append(interpolated)
revised_y = []
for each in y_list:
    interpolated = []
    interpolated = interpolate_list(each, max_length)
    # print("Interpolated List:", interpolated_list)
    revised_y.append(interpolated)
revised_z = []
for each in z_list:
    interpolated = []
    interpolated = interpolate_list(each, max_length)
    # print("Interpolated List:", interpolated_list)
    revised_z.append(interpolated)

print(len(label), len(revised_z[0]), len(revised_z))

#  embed 3 dimensional data into 3D matrix
data_3d = [(x, y, z) for x, y, z in zip(revised_x, revised_y, revised_z)]
data_3d_concatenate = np.column_stack((revised_x, revised_y, revised_z)) # single array input
print(data_3d[0], len(data_3d))
print(data_3d_concatenate[0], len(data_3d_concatenate))

# ML models
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB

features, labels = shuffle(data_3d_concatenate, label, random_state=38)
# Split the shuffled data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.1,  random_state=42)


count_unique_numbers = {}
for num in y_test:
    count_unique_numbers[num] = count_unique_numbers.get(num, 0) + 1

print(count_unique_numbers, count_unique_numbers[0])
print(len(y_test))

# Initialize the classifier
classifiers = [DecisionTreeClassifier(),
               RandomForestClassifier(),
               # GradientBoostingClassifier(), # quite time-consuming, similar results with RandomForestClassifier()
               # SVC(), # time-consuming
               LogisticRegression(solver='liblinear', max_iter=1000),  # low accuracy
               KNeighborsClassifier(),
               # MultinomialNB(),
               GaussianNB(),
               ]

for classifier in classifiers:
  # Train the classifier
  classifier.fit(X_train, y_train)

  # Make predictions on the test set
  predictions = classifier.predict(X_test)

  # Evaluate accuracy
  accuracy = accuracy_score(y_test, predictions)
  i = 0
  count_0 = 0
  count_1 = 0
  count_2 = 0
  count_3 = 0
  count_4 = 0
  while i < len(y_test):
      if y_test[i] == predictions[i]:
          if y_test[i] == 0:
              count_0 += 1
          if y_test[i] == 1:
              count_1 += 1
          if y_test[i] == 2:
              count_2 += 1
          if y_test[i] == 3:
              count_3 += 1
          if y_test[i] == 4:
              count_4 += 1
      i += 1
  accuracy_0 = count_0 / count_unique_numbers[0]
  accuracy_1 = count_1 / count_unique_numbers[1]
  accuracy_2 = count_2 / count_unique_numbers[2]
  accuracy_3 = count_3 / count_unique_numbers[3]
  accuracy_4 = count_4 / count_unique_numbers[4]
  print(f"{classifier},Accuracy: {accuracy}")
  print('%.4f ' % accuracy_4, '%.4f ' % accuracy_2, '%.4f ' % accuracy_0, '%.4f ' % accuracy_3, '%.4f ' % accuracy_1)
  print('stand-4', accuracy_4)
  print('sit-2', accuracy_2)
  print('kneeraise-0', accuracy_0)
  print('squat-3', accuracy_3)
  print('lunge-1', accuracy_1)